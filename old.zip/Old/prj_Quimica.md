###Coisas a fazer

---
- [ ] Entender como funciona o paint
- [ ] Fazer um paint 
  - [ ] Selecionar elemento 
  - [ ] Manipular elemento