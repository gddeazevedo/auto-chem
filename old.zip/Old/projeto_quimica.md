# Projeto de Quimica

* ### Quem somos 

| Nomes dos Integrantes | Email                   |
| --------------------- | ----------------------- |
| Gabriel Dias          | gd.deazevedo@gmail.com  |
| Gabriel Vieira        | biel.ilha2021@gmail.com |
| Wesley Ferreira       | wsf.ley@gmail.com       |



---
+ #### Sobre Projeto

Um software **open source** voltado para estudantes e profissionais da área de química que tem como intuito criação e manipulção de compostos orgânicos. 


---

+ #### Objetivo
  
O projeto visa uma plataforma que viabilize 
O projeto visa que 

---

+ #### Informacoes técnicas
---
 Segue aqui informações extramentes técnicas que não tem o intuito algum de ser lida por pessoas que não possui o dom técnico
  


