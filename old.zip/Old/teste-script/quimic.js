const chemicaltools = require('chemicaltools')

console.log(chemicaltools.calculateMass("1H2O"))